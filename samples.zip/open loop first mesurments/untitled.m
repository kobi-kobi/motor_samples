close all; clear all ; clc
for file_freq_name = 0.1:0.1:20;
file_freq_name=2.4

[samples,freq] = reading_file(file_freq_name);
G_places    = find(samples=="G");    
samples_without_G= regexprep(samples,'[^0123456789ABCDEF]',''); 
samples_without_G = samples_without_G(~cellfun(@isempty, samples_without_G));
UD_without_g=hex2unwrap(samples_without_G);
filteared_output=lpf_function(UD_without_g,freq);
filteared_output_with1230321 = addG(samples,filteared_output);
%%

    phase_array = [];
    for i = 1:length(G_places)-1
    cut_period  = filteared_output_with1230321(G_places(i)+1:G_places(i+1)-1);
    phase_array(end+1)=phase_calc(cut_period,freq);
     close all
    end
phase_mean = mean(phase_array);
result=[freq,phase_mean];

    writematrix(result,'result_pos.csv','WriteMode','append')
    disp("for freq      "+freq)
    disp("phase   is " + phase_mean)
    

end

%%

function [output] = addG(array_withG,array_withoutG)

output=zeros(1,length(array_withG));
count=0;
for i = 1:length(array_withG);
    if(array_withG(i)=="G")
       output(i)=1230321;
       count=count+1;
    else   
    output(i)=array_withoutG(i-count);
    end
end
end

function [output] =lpf_function(UD,freq)
Ts =     0.0059;
Y_f = fft(UD);
fs = 1/Ts;

f = (0:length(Y_f)-1)*fs/length(Y_f);
%plot(f,abs(Y_f));
%xlabel('Frequency (Hz)');
%ylabel('Magnitude');
%title('Magnitude');
%
left_freq=find(f>=0.75*freq & f<=1.25*freq);
H=zeros(1,length(Y_f));
H(left_freq)=1;
H((length(H)-left_freq)+2)=1;

filterd_signal=Y_f.*H;
%plot(abs(filterd_signal))
%plot(ifft(filterd_signal))
output=ifft(filterd_signal);
end

function [samples,freq] = reading_file(file_freq_name)
freq = file_freq_name;
fname = 'SinWaveFreqF' + sprintf("%03d", round(freq*10)) + '.mat';
freq=freq/2;

load(fname);


C           = strsplit(DGIMA);
netDgima    = regexprep(C,'[^0-9,A-G]','');
netDgima = netDgima(~cellfun(@isempty, netDgima));


longDgima = netDgima;
longDgima = longDgima(~cellfun(@isempty, longDgima));
n=1;
while n < length(longDgima);
    if strlength(longDgima(n))~=3 && longDgima(n)~="G" ;
       longDgima(n)="";
    end
    if longDgima(n)=="FFF" ||longDgima(n)=="000";
        longDgima(n)="";
    end
    n=n+1;
end
longDgima = longDgima(~cellfun(@isempty, longDgima));
samples = longDgima;

end

function [UD] = hex2unwrap(samples)
D=hex2dec(samples);
D=(D./4096);
D=D.*360;
R=deg2rad(D);
D=rad2deg(R);
UR = unwrap(R);
UD=rad2deg(UR);
end

function [phsae] = phase_calc(UD,freq)
Ts =     0.0059;
numofsamples = Ts*length(UD);                   %length of period
T = 0:Ts:numofsamples;  
x=T(1:length(UD));                        


UDM = movmean(UD,20);
plot(x,UDM,"red");
hold on                                                     %equvivlent sinwave
 y_sin = sin(2*pi*freq*x)*max(abs(UDM)) ;
 plot(x,y_sin(1:length(x)),"blue");
 xlim ([x(1) x(end)]);
 [a_sample b_sample]=max(UDM);
 [a_sinwave b_sinwave]= max(y_sin);
 td = Ts*(b_sample-b_sinwave);
 phsae = 360*td* freq; 
end